package gvs.com.placementmanagementsystem;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class StudentLog extends AppCompatActivity {
TextView sreg;
    SharedPreferences sharedPreferences;
    public static final String MyPREFERENCES = "MyPrefs" ;
     DatabaseReference databaseReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_log);
        sreg=(TextView)findViewById(R.id.sreg);
        sharedPreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
       databaseReference = FirebaseDatabase.getInstance().getReference().child("StudentDetails");

        sreg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(StudentLog.this,StudentRegister.class);
                startActivity(intent);
            }
        });
    }
    public void studentlog(View view){
        final String email=((EditText)findViewById(R.id.sroll)).getText().toString();
        final String password=((EditText)findViewById(R.id.spassword)).getText().toString();
        if (email.length() <= 1 || password.length() <= 1 ) {
            Toast.makeText(StudentLog.this, "All Fields Should be More then 3 Characters", Toast.LENGTH_SHORT).show();

        } else {

            databaseReference.orderByChild("sid_password_status").equalTo(email+"_"+password+"_"+"Verified").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if(dataSnapshot.exists())
                    {
                        for (DataSnapshot childSnapshot : dataSnapshot.getChildren()) {
                            String key = childSnapshot.getKey();
                            String fname = childSnapshot.child("sname").getValue().toString();
                            String femail = childSnapshot.child("semail").getValue().toString();
                            String sem = childSnapshot.child("sem").getValue().toString();
                            String fid = childSnapshot.child("sid").getValue().toString();
                            String faddress = childSnapshot.child("saddress").getValue().toString();
                            String fphone = childSnapshot.child("sphone").getValue().toString();
                            String fdob = childSnapshot.child("sdob").getValue().toString();
                            String branch = childSnapshot.child("branch").getValue().toString();

                            Log.d("name is", key);
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putString("sname", fname);
                            editor.putString("key", key);
                            editor.putString("semail", femail);
                            editor.putString("sem", sem);
                            editor.putString("sid", fid);
                            editor.putString("saddress", faddress);
                            editor.putString("sphone", fphone);
                            editor.putString("sdob", fdob);
                            editor.putString("branch", branch);
                            editor.commit();
                            Log.d("keyis", key);
                            Intent intent = new Intent(StudentLog.this, StudentHome.class);
                            startActivity(intent);
                        }
                    }else{
                        Toast.makeText(StudentLog.this, "Failed To Login", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });


        }

    }

}
