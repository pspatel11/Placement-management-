package gvs.com.placementmanagementsystem;

import android.app.FragmentManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.os.StrictMode;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;


public class UpdateResumay extends Fragment {
    Button selectFile,upload,dstore;
    TextView notification;
    FirebaseStorage storage;
    FirebaseDatabase database;
    Uri pdfUri;
    String url;
    ProgressDialog progressDialog;
    DatabaseReference databaseReference;
    int fileid;
    SharedPreferences sharedPreferences;
    public static final String MyPREFERENCES = "MyPrefs";
    String usn,key;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_update_resumay, container, false);
        sharedPreferences = getActivity().getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        usn=sharedPreferences.getString("sid","");
        databaseReference= FirebaseDatabase.getInstance().getReference("ResumeDetails");
        StrictMode.ThreadPolicy old = StrictMode.getThreadPolicy();
        StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder(old)
                .permitDiskWrites()
                .build());
        StrictMode.setThreadPolicy(old);

        Bundle bundle=this.getArguments();
        key=bundle.getString("key");
        storage=FirebaseStorage.getInstance();
        database=FirebaseDatabase.getInstance();
        selectFile=(Button)view.findViewById(R.id.selectfile1);
        upload=(Button) view.findViewById(R.id.upload1);
        dstore=(Button) view.findViewById(R.id.dstore1);
        notification=view.findViewById(R.id.notification1);
        selectFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ContextCompat.checkSelfPermission(getContext(), android.Manifest.permission.READ_EXTERNAL_STORAGE)== PackageManager.PERMISSION_GRANTED){
                    selectPdf();
                }else {
                    ActivityCompat.requestPermissions(getActivity(),new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE},9);
                }
            }
        });
        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(pdfUri!=null)
                    uploadFile(pdfUri);
                else
                    Toast.makeText(getContext(),"Please Provide Permission",Toast.LENGTH_LONG).show();


            }
        });
        dstore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                store(v);
            }
        });

        return view;
    }

    private void uploadFile(Uri pdfUri){
        progressDialog=new ProgressDialog(getContext());
        progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        progressDialog.setTitle("Uploading File....");
        progressDialog.setProgress(0);
        progressDialog.show();
        final String fileName=System.currentTimeMillis()+"";
        StorageReference storageReference=storage.getReference();
        storageReference.child("uploads").child(fileName).putFile(pdfUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                url=taskSnapshot.getDownloadUrl().toString();
                Log.d("url is",url);
                DatabaseReference reference=database.getReference();
                reference.child(fileName).setValue(fileName).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful())
                            Toast.makeText(getContext(),"File Uploaded Sucessfully",Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(getContext(),"File Uploaded Failed",Toast.LENGTH_LONG).show();

                    }
                });
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getContext(),"File Uploaded Failed",Toast.LENGTH_LONG).show();

            }
        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                int currentProgress=(int)(100*taskSnapshot.getBytesTransferred()/taskSnapshot.getTotalByteCount());
                progressDialog.setProgress(currentProgress);
            }
        });
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode==9 && grantResults[0]== PackageManager.PERMISSION_GRANTED){
            selectPdf();
        }else {
            Toast.makeText(getContext(),"Please Provide Permission",Toast.LENGTH_LONG).show();
        }
    }
    private void selectPdf(){
        Intent intent=new Intent();
        intent.setType("application/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent,86);
    }
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==86 && resultCode==getActivity().RESULT_OK && data!=null){
            pdfUri=data.getData();
            Log.d("pdfuri", String.valueOf(pdfUri));
            fileid= Integer.parseInt(data.getData().getLastPathSegment());
            notification.setText("A File is Selected :"+data.getData().getLastPathSegment() );
            Log.d("fileid", String.valueOf(fileid));
        }else{
            Toast.makeText(getContext(),"Please Select  File",Toast.LENGTH_LONG).show();

        }
    }

    public void store(View view){

        databaseReference.orderByChild("id").equalTo(key).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    ResumeModel res = new ResumeModel();
                    res.setId(key);
                    res.setResume(url);
                    res.setUsn(usn);
                    res.setUsn_resume(usn+"_"+url);
                    databaseReference.child(key).setValue(res);
                    Toast.makeText(getContext(), "Details Update Sucess", Toast.LENGTH_SHORT).show();
                    FragmentManager fm=getFragmentManager();
                    fm.beginTransaction().replace(R.id.student_fragment_container,new Viewresume()).commit();


                }else{
                    Toast.makeText(getContext(),"Failed to Upload",Toast.LENGTH_LONG).show();



                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });





    }
}
