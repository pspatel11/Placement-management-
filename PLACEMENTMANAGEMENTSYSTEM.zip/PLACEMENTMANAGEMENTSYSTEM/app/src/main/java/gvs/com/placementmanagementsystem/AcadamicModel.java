package gvs.com.placementmanagementsystem;

public class AcadamicModel {
    private String id;
    private String tength;
    private String twelth;
    private String sem;
    private String usn;
    private String cgpa;
    private String arrears;
    private String usn_sem_tenght_twelth;
    private String status;
    private String usn_status;

    public AcadamicModel() {
    }

    public AcadamicModel(String id, String tength, String twelth, String sem, String usn, String usn_sem_tenght_twelth, String status, String usn_status) {
        this.id = id;
        this.tength = tength;
        this.twelth = twelth;
        this.sem = sem;
        this.usn = usn;
        this.usn_sem_tenght_twelth = usn_sem_tenght_twelth;
        this.status = status;
        this.usn_status = usn_status;
    }

    public String getCgpa() {
        return cgpa;
    }

    public void setCgpa(String cgpa) {
        this.cgpa = cgpa;
    }

    public String getArrears() {
        return arrears;
    }

    public void setArrears(String arrears) {
        this.arrears = arrears;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTength() {
        return tength;
    }

    public void setTength(String tength) {
        this.tength = tength;
    }

    public String getTwelth() {
        return twelth;
    }

    public void setTwelth(String twelth) {
        this.twelth = twelth;
    }

    public String getSem() {
        return sem;
    }

    public void setSem(String sem) {
        this.sem = sem;
    }

    public String getUsn() {
        return usn;
    }

    public void setUsn(String usn) {
        this.usn = usn;
    }

    public String getUsn_sem_tenght_twelth() {
        return usn_sem_tenght_twelth;
    }

    public void setUsn_sem_tenght_twelth(String usn_sem_tenght_twelth) {
        this.usn_sem_tenght_twelth = usn_sem_tenght_twelth;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getUsn_status() {
        return usn_status;
    }

    public void setUsn_status(String usn_status) {
        this.usn_status = usn_status;
    }
}
