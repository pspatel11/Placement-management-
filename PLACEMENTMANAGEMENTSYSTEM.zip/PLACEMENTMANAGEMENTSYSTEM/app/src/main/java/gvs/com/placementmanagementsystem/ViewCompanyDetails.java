package gvs.com.placementmanagementsystem;

import android.app.FragmentManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


public class ViewCompanyDetails extends Fragment {
    ListView club_list;
    public static final String MyPREFERENCES = "MyPrefs";
    SharedPreferences sharedPreferences;
    DatabaseReference databaseReference;
    List<CompanyModel> detailsList;
    CalendarView calendarView;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_view_company_details, container, false);
        club_list=(ListView)view.findViewById(R.id.company_list);
        databaseReference= FirebaseDatabase.getInstance().getReference("CompanyDetails");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    detailsList=new ArrayList<CompanyModel>();
                    for(DataSnapshot childSnapshot: dataSnapshot.getChildren()) {
                        CompanyModel fdel = childSnapshot.getValue(CompanyModel.class);
                        detailsList.add(fdel);
                    }
                    CustomAdoptor customAdoptor= new CustomAdoptor();
                    club_list.setAdapter(customAdoptor);

                }else{

                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        return view;
    }
    class CustomAdoptor extends BaseAdapter {

        @Override
        public int getCount() {
            return detailsList.size();
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(final int i, View view, ViewGroup viewGroup) {
            view = getActivity().getLayoutInflater().inflate(R.layout.companylist,null);
            TextView cname=(TextView)view.findViewById(R.id.cname);
            TextView role=(TextView)view.findViewById(R.id.role);
            TextView locationn=(TextView)view.findViewById(R.id.locationn);
            TextView salaryy=(TextView)view.findViewById(R.id.salaryy);
            TextView positions=(TextView)view.findViewById(R.id.positions);
            TextView datee=(TextView)view.findViewById(R.id.datee);
            TextView branchh=(TextView)view.findViewById(R.id.branchh);
            TextView tenghtt=(TextView)view.findViewById(R.id.tenghtt);
            TextView semm=(TextView)view.findViewById(R.id.semm);
            TextView persentage=(TextView)view.findViewById(R.id.persentage);
            TextView cgpa=(TextView)view.findViewById(R.id.cgpa);
            TextView arrears=(TextView)view.findViewById(R.id.arrears);
            Button edit=(Button)view.findViewById(R.id.edit);
            Button delete=(Button)view.findViewById(R.id.delete);
            Button eligible=(Button)view.findViewById(R.id.eligible);

            cname.setText(detailsList.get(i).getCompanyName());
            role.setText(detailsList.get(i).getJobRole());
            locationn.setText(detailsList.get(i).getCompanyLocation());
            salaryy.setText(detailsList.get(i).getSalary());
            positions.setText(detailsList.get(i).getVacancyes());
            datee.setText(detailsList.get(i).getDate());
            branchh.setText(detailsList.get(i).getBranch());
            tenghtt.setText(detailsList.get(i).getTength());
            semm.setText(detailsList.get(i).getSem());
            cgpa.setText(detailsList.get(i).getCgpa());
            arrears.setText(detailsList.get(i).getArrears());
            persentage.setText(detailsList.get(i).getInter());

            delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    databaseReference.child(detailsList.get(i).getId()).removeValue();
                    Toast.makeText(getContext(), "Delete  Sucess", Toast.LENGTH_SHORT).show();
                    FragmentManager fm=getFragmentManager();
                    fm.beginTransaction().replace(R.id.placement_fragment_container,new ViewCompanyDetails()).commit();

                }
            });
            edit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle=new Bundle();
                    bundle.putString("cname",detailsList.get(i).getCompanyName());
                    bundle.putString("jobrole",detailsList.get(i).getJobRole());
                    bundle.putString("location",detailsList.get(i).getCompanyLocation());
                    bundle.putString("salary",detailsList.get(i).getSalary());
                    bundle.putString("position",detailsList.get(i).getVacancyes());
                    bundle.putString("date",detailsList.get(i).getDate());
                    bundle.putString("branch",detailsList.get(i).getBranch());
                    bundle.putString("tength",detailsList.get(i).getTength());
                    bundle.putString("twelth",detailsList.get(i).getInter());
                    bundle.putString("sem",detailsList.get(i).getSem());
                    bundle.putString("id",detailsList.get(i).getId());
                    bundle.putString("cgpa",detailsList.get(i).getCgpa());
                    bundle.putString("arrears",detailsList.get(i).getArrears());
                    UpdateCOmpany cname=new UpdateCOmpany();
                    cname.setArguments(bundle);
                    FragmentManager fm=getFragmentManager();
                    fm.beginTransaction().replace(R.id.placement_fragment_container,cname).commit();
                }
            });

            eligible.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Bundle bundle=new Bundle();
                    bundle.putString("cname",detailsList.get(i).getCompanyName());
                    bundle.putString("jobrole",detailsList.get(i).getJobRole());
                    bundle.putString("location",detailsList.get(i).getCompanyLocation());
                    bundle.putString("salary",detailsList.get(i).getSalary());
                    bundle.putString("position",detailsList.get(i).getVacancyes());
                    bundle.putString("date",detailsList.get(i).getDate());
                    bundle.putString("branch",detailsList.get(i).getBranch());
                    bundle.putString("tength",detailsList.get(i).getTength());
                    bundle.putString("twelth",detailsList.get(i).getInter());
                    bundle.putString("sem",detailsList.get(i).getSem());
                    bundle.putString("id",detailsList.get(i).getId());
                    bundle.putString("cgpa",detailsList.get(i).getCgpa());
                    bundle.putString("arrears",detailsList.get(i).getArrears());
                    EligibleStudentsFragment cname=new EligibleStudentsFragment();
                    cname.setArguments(bundle);
                    FragmentManager fm=getFragmentManager();
                    fm.beginTransaction().replace(R.id.placement_fragment_container,cname).commit();
                }
            });


            return view;
        }
    }
}
