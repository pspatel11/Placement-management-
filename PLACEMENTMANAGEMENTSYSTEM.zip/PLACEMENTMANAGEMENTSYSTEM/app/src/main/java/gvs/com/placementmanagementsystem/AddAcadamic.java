package gvs.com.placementmanagementsystem;

import android.app.FragmentManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Random;


public class AddAcadamic extends Fragment {
    EditText tenght;
    EditText tweth;
    EditText sem;
    EditText cgpa;
    EditText arrears;
    public static final String MyPREFERENCES = "MyPrefs";
    SharedPreferences sharedPreferences;
    DatabaseReference databaseReference;
    Button add_btn ;
    String ttwenth,twethh,semister,key,usn;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_add_acadamic, container, false);
        sharedPreferences = this.getActivity().getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);

        databaseReference= FirebaseDatabase.getInstance().getReference("AcademicDetails");
        key=sharedPreferences.getString("key","");
        usn=sharedPreferences.getString("sid","");
        tenght= (EditText) view.findViewById(R.id.tength);

        tweth = ((EditText) view.findViewById(R.id.tweth));
        sem = ((EditText) view.findViewById(R.id.sem));
        cgpa = ((EditText) view.findViewById(R.id.cgpa));
        arrears = ((EditText) view.findViewById(R.id.arrears));
        add_btn=(Button)view.findViewById(R.id.aca_button);
        add_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ttwenth=tenght.getText().toString();
                twethh=tweth.getText().toString();
                semister=sem.getText().toString();

                if(ttwenth.length() >=1 && twethh.length()>=1 && semister.length()>=1){
                    databaseReference.orderByChild("usn").equalTo(usn).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            if(dataSnapshot.exists()){
                                Toast.makeText(getContext(),"Details Already Exits",Toast.LENGTH_LONG).show();
                            }else {
                                String id=databaseReference.push().getKey();
                                AcadamicModel acdel=new AcadamicModel();
                                acdel.setId(id);
                                acdel.setSem(semister);
                                acdel.setStatus("NotVerified");
                                acdel.setTength(ttwenth);
                                acdel.setTwelth(twethh);
                                acdel.setUsn(usn);
                                acdel.setCgpa(cgpa.getText().toString());
                                acdel.setArrears(arrears.getText().toString());
                                acdel.setUsn_sem_tenght_twelth(usn+"_"+semister+"_"+ttwenth+"_"+twethh);
                                acdel.setUsn_status(usn+"_"+"NotVerified");
                                databaseReference.child(id).setValue(acdel);
                                Toast.makeText(getContext(), "Details Added Sucess", Toast.LENGTH_SHORT).show();
                                FragmentManager fm=getFragmentManager();
                                fm.beginTransaction().replace(R.id.student_fragment_container,new ViewAccadamics()).commit();


                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }
                    });
                }else{
                    Toast.makeText(getContext(),"All feilds Should be more than 1 Character",Toast.LENGTH_LONG).show();
                }
            }
        });

        return  view;

    }


}
