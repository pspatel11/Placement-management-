package gvs.com.placementmanagementsystem;

import android.app.FragmentManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


public class VerifyAcadamics extends Fragment {
    ListView club_list;
    public static final String MyPREFERENCES = "MyPrefs";
    SharedPreferences sharedPreferences;
    DatabaseReference databaseReference;
    List<AcadamicModel> detailsList;
    CalendarView calendarView;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_verify_acadamics, container, false);
        club_list=(ListView)view.findViewById(R.id.marks_list1);
        databaseReference= FirebaseDatabase.getInstance().getReference("AcademicDetails");

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    detailsList=new ArrayList<AcadamicModel>();
                    for(DataSnapshot childSnapshot: dataSnapshot.getChildren()) {
                        AcadamicModel fdel = childSnapshot.getValue(AcadamicModel.class);
                        detailsList.add(fdel);
                    }
                   CustomAdoptor customAdoptor= new CustomAdoptor();
                    club_list.setAdapter(customAdoptor);

                }else{

                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        return view;
    }
    class CustomAdoptor extends BaseAdapter {

        @Override
        public int getCount() {
            return detailsList.size();
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(final int i, View view, ViewGroup viewGroup) {
            view = getActivity().getLayoutInflater().inflate(R.layout.acadamiclist1,null);
            TextView tength=(TextView)view.findViewById(R.id.tength1);
            TextView twelth=(TextView)view.findViewById(R.id.twelth1);
            TextView semm=(TextView)view.findViewById(R.id.semm1);
            TextView status=(TextView)view.findViewById(R.id.status1);
            TextView usn=(TextView)view.findViewById(R.id.usn);
            TextView cgpa=(TextView)view.findViewById(R.id.cgpa);
            TextView arrears=(TextView)view.findViewById(R.id.arrears);
            Button vbtn=(Button)view.findViewById(R.id.update_btn1);

            tength.setText(detailsList.get(i).getTength());
            twelth.setText(detailsList.get(i).getTwelth());
            semm.setText(detailsList.get(i).getSem());
            final String id=detailsList.get(i).getId();
            status.setText(detailsList.get(i).getStatus());
            usn.setText(detailsList.get(i).getUsn());
            cgpa.setText(detailsList.get(i).getCgpa());
            arrears.setText(detailsList.get(i).getArrears());
            vbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                   AcadamicModel model=new AcadamicModel(detailsList.get(i).getId(),detailsList.get(i).getTength(),detailsList.get(i).getTwelth(),detailsList.get(i).getSem(),detailsList.get(i).getUsn(),detailsList.get(i).getUsn_sem_tenght_twelth(),"OriginalMarks",detailsList.get(i).getUsn()+"_"+"OriginalMarks");
                   model.setCgpa(detailsList.get(i).getCgpa());
                   model.setArrears(detailsList.get(i).getArrears());
                   databaseReference.child(detailsList.get(i).getId()).setValue(model);
                }
            });
            return view;
        }
    }

}
