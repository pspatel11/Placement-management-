package gvs.com.placementmanagementsystem;

public class CoordinatorModel {
    private  String id;
    private String name;
    private String email;
    private String phone;
    private String cid;
    private String branch;
    private String password;
    private String cid_password;
    private String cid_phone_email;

    public CoordinatorModel() {
    }

    public CoordinatorModel(String id, String name, String email, String phone, String cid, String branch, String password, String cid_password, String cid_phone_email) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.cid = cid;
        this.branch = branch;
        this.password = password;
        this.cid_password = cid_password;
        this.cid_phone_email = cid_phone_email;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getCid_password() {
        return cid_password;
    }

    public void setCid_password(String cid_password) {
        this.cid_password = cid_password;
    }

    public String getCid_phone_email() {
        return cid_phone_email;
    }

    public void setCid_phone_email(String cid_phone_email) {
        this.cid_phone_email = cid_phone_email;
    }
}
