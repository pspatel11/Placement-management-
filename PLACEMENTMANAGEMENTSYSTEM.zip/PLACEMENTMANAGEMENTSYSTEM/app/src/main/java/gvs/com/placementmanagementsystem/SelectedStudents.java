package gvs.com.placementmanagementsystem;

import android.app.FragmentManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


public class SelectedStudents extends Fragment {
    public static final String MyPREFERENCES = "MyPrefs";
    SharedPreferences sharedPreferences;

    Button add_btn;
    DatabaseReference databaseReference;
    DatabaseReference databaseReference2,databaseReference3;
    EditText descc;
    Spinner cname,usn;
    String usnnumber,companyname,descrption;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final View view= inflater.inflate(R.layout.fragment_selected_students, container, false);
        databaseReference= FirebaseDatabase.getInstance().getReference("CompanyDetails");
        databaseReference2= FirebaseDatabase.getInstance().getReference("ApplyDetails");
        databaseReference3= FirebaseDatabase.getInstance().getReference("ViewSelectedStudentdetails");

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                List<String> fdel=new ArrayList<>();
                for (DataSnapshot areaSnapshot: dataSnapshot.getChildren()) {


                    String areaName = areaSnapshot.child("companyName").getValue(String.class);
                    fdel.add(areaName);
                }
                Spinner areaSpinner = (Spinner)view.findViewById(R.id.companyes1);
                final String[] areas = fdel.toArray(new String[fdel.size()]);
                ArrayAdapter<String> areasAdapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_item, areas);
                areasAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                areaSpinner.setAdapter(areasAdapter);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        databaseReference2.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                List<String> fdel=new ArrayList<>();
                for (DataSnapshot areaSnapshot: dataSnapshot.getChildren()) {


                    String areaName = areaSnapshot.child("usn").getValue(String.class);
                    fdel.add(areaName);
                }
                Spinner areaSpinner = (Spinner)view.findViewById(R.id.usn1);
                final String[] areas1 = fdel.toArray(new String[fdel.size()]);
                ArrayAdapter<String> areasAdapter1 = new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_item, areas1);
                areasAdapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                areaSpinner.setAdapter(areasAdapter1);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        descc=(EditText)view.findViewById(R.id.descrption1);
        cname = (Spinner)view.findViewById(R.id.companyes1);
        usn = (Spinner)view.findViewById(R.id.usn1);
        Button button =(Button)view.findViewById(R.id.select_button1);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                companyname = cname.getSelectedItem().toString();
                usnnumber = usn.getSelectedItem().toString();
                descrption=descc.getText().toString();

                databaseReference3.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        String id=databaseReference3.push().getKey();
                        InterProcess ndel=new InterProcess();
                        ndel.setId(id);
                        ndel.setCompany(companyname);
                        ndel.setDescrption(descrption);
                        ndel.setUns(usnnumber);
                        databaseReference3.child(id).setValue(ndel);
                        Toast.makeText(getContext(), "Send Notification Sucess", Toast.LENGTH_SHORT).show();
                        FragmentManager fm=getFragmentManager();
                        fm.beginTransaction().replace(R.id.placement_fragment_container,new PHome()).commit();



                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });



            }
        });
        return view;
    }


}
