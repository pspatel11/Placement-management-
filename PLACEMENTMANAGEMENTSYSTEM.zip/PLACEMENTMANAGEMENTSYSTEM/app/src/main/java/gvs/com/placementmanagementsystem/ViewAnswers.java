package gvs.com.placementmanagementsystem;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


public class ViewAnswers extends Fragment {

    ListView club_list;
    public static final String MyPREFERENCES = "MyPrefs";
    SharedPreferences sharedPreferences;
    DatabaseReference databaseReference;
    List<AnswerModel> detailsList;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_view_answers, container, false);
        sharedPreferences = this.getActivity().getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        databaseReference= FirebaseDatabase.getInstance().getReference("AnswerDetails");
        final String usn=sharedPreferences.getString("sid","");
        club_list=(ListView)view.findViewById(R.id.anslist);
        databaseReference.orderByChild("qby").equalTo(usn).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                detailsList=new ArrayList<AnswerModel>();
                for(DataSnapshot childSnapshot: dataSnapshot.getChildren()) {
                    AnswerModel clubdel=childSnapshot.getValue(AnswerModel.class);
                    detailsList.add(clubdel);
                }
                CustomAdoptor customAdoptor= new CustomAdoptor();
                club_list.setAdapter(customAdoptor);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        return view;
    }

    class CustomAdoptor extends BaseAdapter {

        @Override
        public int getCount() {
            return detailsList.size();
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(final int i, View view, ViewGroup viewGroup) {
            view = getActivity().getLayoutInflater().inflate(R.layout.anslist,null);
            TextView query=(TextView)view.findViewById(R.id.query11);
            final TextView answer=(TextView)view.findViewById(R.id.answer11);

            Button send=(Button)view.findViewById(R.id.answer);

            query.setText(detailsList.get(i).getQuery());
            answer.setText(detailsList.get(i).getAnswer());




            return view;
        }
    }
}
