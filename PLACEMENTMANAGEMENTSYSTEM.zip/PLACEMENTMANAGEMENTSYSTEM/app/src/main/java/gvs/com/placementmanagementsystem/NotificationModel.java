package gvs.com.placementmanagementsystem;

public class NotificationModel {
    private String id;
    private String title;
    private String desscc;
    private String companyname;

    public NotificationModel() {
    }

    public NotificationModel(String id, String title, String desscc, String companyname) {
        this.id = id;
        this.title = title;
        this.desscc = desscc;
        this.companyname = companyname;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDesscc() {
        return desscc;
    }

    public void setDesscc(String desscc) {
        this.desscc = desscc;
    }

    public String getCompanyname() {
        return companyname;
    }

    public void setCompanyname(String companyname) {
        this.companyname = companyname;
    }
}
