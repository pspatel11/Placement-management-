package gvs.com.placementmanagementsystem;

import android.app.FragmentManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


public class StuviewCompanyDetails extends Fragment {
    ListView club_list;
    public static final String MyPREFERENCES = "MyPrefs";
    SharedPreferences sharedPreferences;
    DatabaseReference databaseReference,databaseReference2;
    List<CompanyModel> detailsList;
    CalendarView calendarView;
String usn,branch,sem; int semmister;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_stuview_company_details, container, false);
        club_list=(ListView)view.findViewById(R.id.company_list1);
        sharedPreferences = this.getActivity().getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        usn=sharedPreferences.getString("sid","");
        branch=sharedPreferences.getString("branch","");
        sem=sharedPreferences.getString("sem","");
        semmister= Integer.parseInt(sem);
        databaseReference2= FirebaseDatabase.getInstance().getReference("AcademicDetails");

        databaseReference= FirebaseDatabase.getInstance().getReference("CompanyDetails");
        databaseReference.orderByChild("branch").equalTo(branch).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    detailsList=new ArrayList<CompanyModel>();
                    for(DataSnapshot childSnapshot: dataSnapshot.getChildren()) {
                        CompanyModel fdel = childSnapshot.getValue(CompanyModel.class);
                        detailsList.add(fdel);
                    }
                    CustomAdoptor customAdoptor= new CustomAdoptor();
                    club_list.setAdapter(customAdoptor);

                }else{

                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


        return view;
    }

    class CustomAdoptor extends BaseAdapter {

        @Override
        public int getCount() {
            return detailsList.size();
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(final int i, View view, ViewGroup viewGroup) {
            view = getActivity().getLayoutInflater().inflate(R.layout.companylist1,null);
            TextView cname=(TextView)view.findViewById(R.id.cname1);
            TextView role=(TextView)view.findViewById(R.id.role1);
            TextView locationn=(TextView)view.findViewById(R.id.locationn1);
            TextView salaryy=(TextView)view.findViewById(R.id.salaryy1);
            TextView positions=(TextView)view.findViewById(R.id.positions1);
            TextView datee=(TextView)view.findViewById(R.id.datee1);
            TextView branchh=(TextView)view.findViewById(R.id.branchh1);
            TextView tenghtt=(TextView)view.findViewById(R.id.tenghtt1);
            final TextView semm=(TextView)view.findViewById(R.id.semm1);
            TextView persentage=(TextView)view.findViewById(R.id.persentage1);
            TextView cgpa=(TextView)view.findViewById(R.id.cgpa);
            TextView arrears=(TextView)view.findViewById(R.id.arrears);
            Button apply=(Button)view.findViewById(R.id.apply);


            cname.setText(detailsList.get(i).getCompanyName());
            role.setText(detailsList.get(i).getJobRole());
            locationn.setText(detailsList.get(i).getCompanyLocation());
            salaryy.setText(detailsList.get(i).getSalary());
            positions.setText(detailsList.get(i).getVacancyes());
            datee.setText(detailsList.get(i).getDate());
            branchh.setText(detailsList.get(i).getBranch());
            tenghtt.setText(detailsList.get(i).getTength());
            semm.setText(detailsList.get(i).getSem());
            persentage.setText(detailsList.get(i).getInter());
            arrears.setText(detailsList.get(i).getArrears());
            cgpa.setText(detailsList.get(i).getCgpa());
            apply.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(semmister >=6){
                        databaseReference2.orderByChild("usn").equalTo(usn).addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot) {
                                if(dataSnapshot.exists()){
                                    for(DataSnapshot childSnapshot: dataSnapshot.getChildren()) {
                                        AcadamicModel fdel = childSnapshot.getValue(AcadamicModel.class);
                                      String tength=fdel.getTength();
                                        String inter=fdel.getTwelth();
                                        String sem=fdel.getSem();
                                        String reqtenght=detailsList.get(i).getTength();
                                        String reqInter=detailsList.get(i).getInter();
                                        String reqSem=detailsList.get(i).getSem();
                                        int tenghtper=Integer.parseInt(tength);
                                        int interper=Integer.parseInt(inter);
                                        int semper=Integer.parseInt(sem);
                                        int reqtenghtper=Integer.parseInt(reqtenght);
                                        int reqSemtper=Integer.parseInt(reqSem);
                                        int reqInterper=Integer.parseInt(reqInter);
                                        if (reqtenghtper<=tenghtper && reqInterper <= interper && reqSemtper <= semper){
                                            Bundle bundle=new Bundle();
                                            bundle.putString("companyname",detailsList.get(i).getCompanyName());
                                            bundle.putString("key",detailsList.get(i).getId());
                                            bundle.putString("date",detailsList.get(i).getDate());
                                            ApplytoCompany company=new ApplytoCompany();
                                            company.setArguments(bundle);
                                            FragmentManager fm=getFragmentManager();
                                            fm.beginTransaction().replace(R.id.student_fragment_container,company).commit();



                                        }else{
                                            Toast.makeText(getContext(),"your Not Eligible to apply Required Persentage Not Available",Toast.LENGTH_LONG).show();

                                        }


                                    }

                                }
                            }

                            @Override
                            public void onCancelled(DatabaseError databaseError) {

                            }
                        });
                    }else{
                        Toast.makeText(getContext(),"your Not Eligible to apply",Toast.LENGTH_LONG).show();
                    }

                }
            });



            return view;
        }
    }
}
