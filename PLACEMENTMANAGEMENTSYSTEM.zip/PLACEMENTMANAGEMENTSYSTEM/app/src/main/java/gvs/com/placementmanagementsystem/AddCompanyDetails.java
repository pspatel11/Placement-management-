package gvs.com.placementmanagementsystem;

import android.app.FragmentManager;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;


public class AddCompanyDetails extends Fragment {
    EditText cname;
    EditText role;
    EditText location;
    EditText salary;
    EditText phone;
    EditText positions;
    EditText tength,date;
    EditText inter;
    EditText sem;
    Spinner itype,branch;
    EditText cgpa;
    EditText arrears;

    DatabaseReference databaseReference;
    Button add_btn ;
    String companyName,jobRole,companyLocation,salaryy,jobpostions,tengthper,interper,senaggregate,interviewDate,branchh,typee;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_add_company_details, container, false);
        databaseReference= FirebaseDatabase.getInstance().getReference("CompanyDetails");
        ArrayList<String> type = new ArrayList<String>();
        type.add("CS");
        type.add("EEE");
        type.add("ECE");
        type.add("MECH");
        type.add("CIVIL");
        type.add("IT");

        final Spinner My_spinner1 = (Spinner)view.findViewById(R.id.branches);
        final ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(getContext(), android.R.layout.simple_list_item_1, type);
        My_spinner1.setAdapter(adapter1);

        final ArrayList<String> type1 = new ArrayList<String>();
        type1.add("OffCampus");
        type1.add("OnCampus");


        final Spinner My_spinner = (Spinner)view.findViewById(R.id.interviewtype);
        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_list_item_1, type1);
        My_spinner.setAdapter(adapter);



        cname = ((EditText) view.findViewById(R.id.cname));
        role = ((EditText) view.findViewById(R.id.jobrole));
        location = ((EditText) view.findViewById(R.id.clocation));
        salary = ((EditText) view.findViewById(R.id.salary));
        positions = ((EditText) view.findViewById(R.id.positions));
        tength = ((EditText) view.findViewById(R.id.tengthper));
        inter = ((EditText) view.findViewById(R.id.interper));
        sem = ((EditText) view.findViewById(R.id.semper));
        date = ((EditText) view.findViewById(R.id.datee));
        itype=(Spinner)view.findViewById(R.id.interviewtype);
        branch=(Spinner)view.findViewById(R.id.branches);
        add_btn=(Button) view.findViewById(R.id.company_btn);
        cgpa = ((EditText) view.findViewById(R.id.cgpa));
        arrears = ((EditText) view.findViewById(R.id.arrears));
        add_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                companyName=cname.getText().toString();
                jobRole=role.getText().toString();
                companyLocation=location.getText().toString();
                salaryy=salary.getText().toString();
                jobpostions=positions.getText().toString();
                tengthper=tength.getText().toString();
                interper=inter.getText().toString();
                senaggregate=sem.getText().toString();
                interviewDate=date.getText().toString();
                branchh=branch.getSelectedItem().toString();
                typee=itype.getSelectedItem().toString();
                if(companyName.length()>=4 && jobRole.length() >=4 && companyLocation.length() >=4 && tengthper.length() >=2 && interper.length() >=2 && senaggregate.length() >=2 && interviewDate.length() >=4){
                databaseReference.orderByChild("companyname_date").equalTo(companyLocation+"_"+interviewDate).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if(dataSnapshot.exists()){
                            Toast.makeText(getContext(), "Already Exit", Toast.LENGTH_SHORT).show();

                        }else{
                            String id=databaseReference.push().getKey();
                            CompanyModel cdel=new CompanyModel();
                            cdel.setId(id);
                            cdel.setCompanyName(companyName);
                            cdel.setCompanyLocation(companyLocation);
                            cdel.setJobRole(jobRole);
                            cdel.setSalary(salaryy);
                            cdel.setVacancyes(jobpostions);
                            cdel.setTength(tengthper);
                            cdel.setInter(interper);
                            cdel.setSem(senaggregate);
                            cdel.setIntertype(typee);
                            cdel.setDate(interviewDate);
                            cdel.setBranch(branchh);
                            cdel.setCgpa(cgpa.getText().toString());
                            cdel.setArrears(arrears.getText().toString());
                            cdel.setBranch(branchh);
                            cdel.setCompanyname_date(companyName+"_"+interviewDate);
                            databaseReference.child(id).setValue(cdel);
                            Toast.makeText(getContext(), "Details Added Sucess", Toast.LENGTH_SHORT).show();
                            FragmentManager fm=getFragmentManager();
                            fm.beginTransaction().replace(R.id.placement_fragment_container,new PHome()).commit();
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });}else {
                    Toast.makeText(getContext(), "All Fields More than 4 Characters", Toast.LENGTH_SHORT).show();

                }



            }
        });

        return view;
    }


}
