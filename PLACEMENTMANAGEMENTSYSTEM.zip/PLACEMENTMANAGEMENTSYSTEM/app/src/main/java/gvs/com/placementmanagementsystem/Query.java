package gvs.com.placementmanagementsystem;

import android.app.FragmentManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class Query extends Fragment {
    SharedPreferences sharedPreferences;
    public static final String MyPREFERENCES = "MyPrefs";
    DatabaseReference databaseReference;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_query, container, false);
        sharedPreferences = this.getActivity().getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);

        databaseReference= FirebaseDatabase.getInstance().getReference("Query_Details");

        final String usn=sharedPreferences.getString("sid","");
        final EditText query = ((EditText)view.findViewById(R.id.query));
        Button query_btn=(Button)view.findViewById(R.id.query_btn);
        query_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String query1=query.getText().toString();
                if(query1.length()>=4){
                databaseReference.orderByChild("query_queryby").equalTo(query1+"_"+usn).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if(dataSnapshot.exists()){
                            Toast.makeText(getContext(),"Details already exit",Toast.LENGTH_LONG).show();
                        }else{
                            String id=databaseReference.push().getKey();
                            QueryModel query2=new QueryModel(id,query1,usn,query1+"_"+usn);
                            databaseReference.child(id).setValue(query2);
                            Toast.makeText(getContext(), "Send Sucess", Toast.LENGTH_SHORT).show();

                            FragmentManager fm=getFragmentManager();
                            fm.beginTransaction().replace(R.id.student_fragment_container,new Query()).commit();


                        }

                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });}else {
                    Toast.makeText(getContext(), "All Feilds Should be morethan 4 Characters", Toast.LENGTH_SHORT).show();

                }

            }
        });
        return view;
    }


}
