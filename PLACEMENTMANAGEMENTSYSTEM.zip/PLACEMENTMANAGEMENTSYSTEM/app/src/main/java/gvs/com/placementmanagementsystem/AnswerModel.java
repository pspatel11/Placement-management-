package gvs.com.placementmanagementsystem;

public class AnswerModel {
    private String id;
    private String query;
    private String answer;
    private String qby;

    public AnswerModel() {
    }

    public AnswerModel(String id, String query, String answer, String qby) {
        this.id = id;
        this.query = query;
        this.answer = answer;
        this.qby = qby;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getQuery() {
        return query;
    }

    public void setQuery(String query) {
        this.query = query;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getQby() {
        return qby;
    }

    public void setQby(String qby) {
        this.qby = qby;
    }
}
