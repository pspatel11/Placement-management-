package gvs.com.placementmanagementsystem;

public class ApplyModel {
    private String id;
    private  String usn;
    private String resume;
    private String companyname;
    private String  date;
    private String interkey;
    private String usn_company_date;

    public ApplyModel() {
    }

    public ApplyModel(String id, String usn, String resume, String companyname, String date, String interkey, String usn_company_date) {
        this.id = id;
        this.usn = usn;
        this.resume = resume;
        this.companyname = companyname;
        this.date = date;
        this.interkey = interkey;
        this.usn_company_date = usn_company_date;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsn() {
        return usn;
    }

    public void setUsn(String usn) {
        this.usn = usn;
    }

    public String getResume() {
        return resume;
    }

    public void setResume(String resume) {
        this.resume = resume;
    }

    public String getCompanyname() {
        return companyname;
    }

    public void setCompanyname(String companyname) {
        this.companyname = companyname;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getInterkey() {
        return interkey;
    }

    public void setInterkey(String interkey) {
        this.interkey = interkey;
    }

    public String getUsn_company_date() {
        return usn_company_date;
    }

    public void setUsn_company_date(String usn_company_date) {
        this.usn_company_date = usn_company_date;
    }
}
