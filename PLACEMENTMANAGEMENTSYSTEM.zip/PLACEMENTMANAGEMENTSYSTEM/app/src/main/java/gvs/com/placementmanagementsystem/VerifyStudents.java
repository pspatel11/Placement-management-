package gvs.com.placementmanagementsystem;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


public class VerifyStudents extends Fragment {
    ListView club_list;
    public static final String MyPREFERENCES = "MyPrefs";
    SharedPreferences sharedPreferences;
    DatabaseReference databaseReference;
    List<StudentRegModel> detailsList;
    CalendarView calendarView;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_verify_students, container, false);

        club_list=(ListView)view.findViewById(R.id.asverify_list);
        databaseReference= FirebaseDatabase.getInstance().getReference("StudentDetails");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    detailsList=new ArrayList<StudentRegModel>();
                    for(DataSnapshot childSnapshot: dataSnapshot.getChildren()) {
                        StudentRegModel fdel = childSnapshot.getValue(StudentRegModel.class);
                        detailsList.add(fdel);
                    }
                    CustomAdoptor customAdoptor= new CustomAdoptor();
                    club_list.setAdapter(customAdoptor);

                }else{

                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        return view;
    }

    class CustomAdoptor extends BaseAdapter {

        @Override
        public int getCount() {
            return detailsList.size();
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(final int i, View view, ViewGroup viewGroup) {
            view = getActivity().getLayoutInflater().inflate(R.layout.astuverify_list,null);
            TextView afid=(TextView)view.findViewById(R.id.asid);
            TextView afname=(TextView)view.findViewById(R.id.asname);
            TextView afstatus=(TextView)view.findViewById(R.id.astatus);
            TextView asem=(TextView)view.findViewById(R.id.asem);
            TextView abranch=(TextView)view.findViewById(R.id.abranch);
            Button vbtn=(Button)view.findViewById(R.id.asverify_btn);

            afid.setText(detailsList.get(i).getSid());
            afname.setText(detailsList.get(i).getSname());
            afstatus.setText(detailsList.get(i).getStatus());
            final String id=detailsList.get(i).getId();
            abranch.setText(detailsList.get(i).getBranch());
            asem.setText(detailsList.get(i).getSem());

            vbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    DatabaseReference databaseReference=FirebaseDatabase.getInstance().getReference("StudentDetails");
                    StudentRegModel del=new StudentRegModel(detailsList.get(i).getSid(),id,detailsList.get(i).getSname(),detailsList.get(i).getSemail(),detailsList.get(i).getSphone(),detailsList.get(i).getSem(),detailsList.get(i).getSaddress(),detailsList.get(i).getSdob(),detailsList.get(i).getSpassword(),"Verified",detailsList.get(i).getBranch(),detailsList.get(i).getSid_email_phone(),detailsList.get(i).getSid()+"_"+detailsList.get(i).getSpassword()+"_"+"Verified");
                    databaseReference.child(id).setValue(del);

                }
            });
            return view;
        }
    }
}
