package gvs.com.placementmanagementsystem;

public class CertificateModel {
    private  String id;
    private String certificate;
    private String usn;
    private String usn_certificate;
    private String title;
    private String title_usn;

    public CertificateModel() {
    }

    public CertificateModel(String id, String certificate, String usn, String usn_certificate,String title,String title_usn) {
        this.id = id;
        this.certificate = certificate;
        this.usn = usn;
        this.usn_certificate = usn_certificate;
        this.title=title;
        this.title_usn=title_usn;
    }

    public String getTitle_usn() {
        return title_usn;
    }

    public void setTitle_usn(String title_usn) {
        this.title_usn = title_usn;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCertificate() {
        return certificate;
    }

    public void setCertificate(String certificate) {
        this.certificate = certificate;
    }

    public String getUsn() {
        return usn;
    }

    public void setUsn(String usn) {
        this.usn = usn;
    }

    public String getUsn_certificate() {
        return usn_certificate;
    }

    public void setUsn_certificate(String usn_certificate) {
        this.usn_certificate = usn_certificate;
    }
}
