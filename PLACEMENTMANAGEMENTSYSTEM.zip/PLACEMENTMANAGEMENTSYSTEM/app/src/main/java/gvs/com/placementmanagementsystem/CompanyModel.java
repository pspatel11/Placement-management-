package gvs.com.placementmanagementsystem;

public class CompanyModel {
    private  String id;
    private String companyName;
    private String  jobRole;
    private String companyLocation;
    private String salary;
    private String vacancyes;
    private String intertype;
    private String tength;
    private String inter;
    private String Sem;
    private  String date;
    private String branch;
    private String companyname_date;
    private String cgpa;
    private String arrears;
    public CompanyModel() {
    }

    public CompanyModel(String id, String companyName, String jobRole, String companyLocation, String salary, String vacancyes, String intertype, String tength, String inter, String sem, String date, String branch, String companyname_date) {
        this.id = id;
        this.companyName = companyName;
        this.jobRole = jobRole;
        this.companyLocation = companyLocation;
        this.salary = salary;
        this.vacancyes = vacancyes;
        this.intertype = intertype;
        this.tength = tength;
        this.inter = inter;
        Sem = sem;
        this.date = date;
        this.branch = branch;
        this.companyname_date = companyname_date;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getJobRole() {
        return jobRole;
    }

    public void setJobRole(String jobRole) {
        this.jobRole = jobRole;
    }

    public String getCompanyLocation() {
        return companyLocation;
    }

    public void setCompanyLocation(String companyLocation) {
        this.companyLocation = companyLocation;
    }

    public String getSalary() {
        return salary;
    }

    public void setSalary(String salary) {
        this.salary = salary;
    }

    public String getVacancyes() {
        return vacancyes;
    }

    public void setVacancyes(String vacancyes) {
        this.vacancyes = vacancyes;
    }

    public String getIntertype() {
        return intertype;
    }

    public void setIntertype(String intertype) {
        this.intertype = intertype;
    }

    public String getTength() {
        return tength;
    }

    public void setTength(String tength) {
        this.tength = tength;
    }

    public String getInter() {
        return inter;
    }

    public void setInter(String inter) {
        this.inter = inter;
    }

    public String getSem() {
        return Sem;
    }

    public void setSem(String sem) {
        Sem = sem;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public String getCompanyname_date() {
        return companyname_date;
    }

    public void setCompanyname_date(String companyname_date) {
        this.companyname_date = companyname_date;
    }


    public String getArrears() {
        return arrears;
    }

    public String getCgpa() {
        return cgpa;
    }

    public void setCgpa(String cgpa) {
        this.cgpa = cgpa;
    }

    public void setArrears(String arrears) {
        this.arrears = arrears;
    }
}
