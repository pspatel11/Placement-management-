package gvs.com.placementmanagementsystem;

public class QueryModel {
    private String id;
    private String query;
    private String queryby;
    private String query_queryby;

    public QueryModel() {
    }

    public QueryModel(String id, String query, String queryby, String query_queryby) {
        this.id = id;
        this.query = query;
        this.queryby = queryby;
        this.query_queryby = query_queryby;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getQuery() {
        return query;
    }

    public void setQuery(String query) {
        this.query = query;
    }

    public String getQueryby() {
        return queryby;
    }

    public void setQueryby(String queryby) {
        this.queryby = queryby;
    }

    public String getQuery_queryby() {
        return query_queryby;
    }

    public void setQuery_queryby(String query_queryby) {
        this.query_queryby = query_queryby;
    }
}
