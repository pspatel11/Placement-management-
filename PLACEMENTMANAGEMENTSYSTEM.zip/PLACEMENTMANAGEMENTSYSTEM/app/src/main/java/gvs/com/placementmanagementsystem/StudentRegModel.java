package gvs.com.placementmanagementsystem;

public class StudentRegModel {

    String sid;
    String id;
    String sname;
    String semail;
    String sphone;
    String sem;
    String saddress;
    String sdob;
    String spassword;
    String status;
    String branch;
    String  sid_email_phone;
    String sid_password_status;

    public StudentRegModel() {
    }

    public StudentRegModel(String sid, String id, String sname, String semail, String sphone, String sem, String saddress, String sdob, String spassword, String status, String branch, String sid_email_phone, String sid_password_status) {
        this.sid = sid;
        this.id = id;
        this.sname = sname;
        this.semail = semail;
        this.sphone = sphone;
        this.sem = sem;
        this.saddress = saddress;
        this.sdob = sdob;
        this.spassword = spassword;
        this.status = status;
        this.branch = branch;
        this.sid_email_phone = sid_email_phone;
        this.sid_password_status = sid_password_status;
    }

    public String getSid() {
        return sid;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSname() {
        return sname;
    }

    public void setSname(String sname) {
        this.sname = sname;
    }

    public String getSemail() {
        return semail;
    }

    public void setSemail(String semail) {
        this.semail = semail;
    }

    public String getSphone() {
        return sphone;
    }

    public void setSphone(String sphone) {
        this.sphone = sphone;
    }

    public String getSem() {
        return sem;
    }

    public void setSem(String sem) {
        this.sem = sem;
    }

    public String getSaddress() {
        return saddress;
    }

    public void setSaddress(String saddress) {
        this.saddress = saddress;
    }

    public String getSdob() {
        return sdob;
    }

    public void setSdob(String sdob) {
        this.sdob = sdob;
    }

    public String getSpassword() {
        return spassword;
    }

    public void setSpassword(String spassword) {
        this.spassword = spassword;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public String getSid_email_phone() {
        return sid_email_phone;
    }

    public void setSid_email_phone(String sid_email_phone) {
        this.sid_email_phone = sid_email_phone;
    }

    public String getSid_password_status() {
        return sid_password_status;
    }

    public void setSid_password_status(String sid_password_status) {
        this.sid_password_status = sid_password_status;
    }
}
