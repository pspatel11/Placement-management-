package gvs.com.placementmanagementsystem;

import android.app.FragmentManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class ChangePassword extends Fragment {

    public static final String MyPREFERENCES = "MyPrefs";
    SharedPreferences sharedPreferences;
    DatabaseReference databaseReference;
    Button add_btn;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_change_password, container, false);
        sharedPreferences = this.getActivity().getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        databaseReference= FirebaseDatabase.getInstance().getReference("CoordinatorDetails");

        final EditText fname = ((EditText)view.findViewById(R.id.snpass));
        final EditText fid = ((EditText)view.findViewById(R.id.snrpass));
        add_btn=(Button)view.findViewById(R.id.btn_pass);
        add_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String spass=fname.getText().toString();
                final String srpass=fid.getText().toString();
                if(spass.length()>=4 && srpass.length()>=4){
                final String name=sharedPreferences.getString("name","");
                final String key=sharedPreferences.getString("key","");
                final String email=sharedPreferences.getString("email","");
                final String cid=sharedPreferences.getString("cid","");
                final String phone=sharedPreferences.getString("phone","");
                final String branch=sharedPreferences.getString("branch","");



                if(spass.equals(srpass)){
                   databaseReference.orderByChild("id").equalTo(key).addListenerForSingleValueEvent(new ValueEventListener() {
                       @Override
                       public void onDataChange(DataSnapshot dataSnapshot) {
                           if(dataSnapshot.exists()){
                               for(DataSnapshot childSnapshot : dataSnapshot.getChildren()){
                                   CoordinatorModel cdel=childSnapshot.getValue(CoordinatorModel.class);
                                   cdel.setId(key);
                                   cdel.setBranch(branch);
                                   cdel.setCid(cid);
                                   cdel.setEmail(email);
                                   cdel.setName(name);
                                   cdel.setCid_password(cid+"_"+spass);
                                   cdel.setPassword(spass);
                                   cdel.setCid_phone_email(cid+"_"+phone+"_"+email);
                                   cdel.setPhone(phone);
                                   databaseReference.child(key).setValue(cdel);
                                   new SimpleMail().sendEmail(email, "Password Changed", "Your Password has Been changed");

                                   Toast.makeText(getContext(), "Details Added Sucess", Toast.LENGTH_SHORT).show();
                                   FragmentManager fm=getFragmentManager();
                                   fm.beginTransaction().replace(R.id.cordinator_fragment_container,new CHome()).commit();

                               }
                           }else{

                           }
                       }

                       @Override
                       public void onCancelled(DatabaseError databaseError) {

                       }
                   });



                }else{

                    Toast.makeText(getContext(), "Password Does't Match", Toast.LENGTH_SHORT).show();



                }}else {
                    Toast.makeText(getContext(), "All feilds More than 4 characters", Toast.LENGTH_SHORT).show();

                }
            }
        });
        return view;
    }


}
