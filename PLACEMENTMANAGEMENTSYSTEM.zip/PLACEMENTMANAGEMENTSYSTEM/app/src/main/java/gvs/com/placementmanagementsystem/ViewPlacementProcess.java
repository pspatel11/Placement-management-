package gvs.com.placementmanagementsystem;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CalendarView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


public class ViewPlacementProcess extends Fragment {

    ListView club_list;
    public static final String MyPREFERENCES = "MyPrefs";
    SharedPreferences sharedPreferences;
    DatabaseReference databaseReference;
    List<InterProcess> detailsList;
    CalendarView calendarView;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_view_placement_process, container, false);
        club_list=(ListView)view.findViewById(R.id.selected_list1);
        sharedPreferences = this.getActivity().getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);

        final String usn=sharedPreferences.getString("sid","");

        databaseReference= FirebaseDatabase.getInstance().getReference("SelectedNotification_Details");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    detailsList=new ArrayList<InterProcess>();
                    for(DataSnapshot childSnapshot: dataSnapshot.getChildren()) {
                        InterProcess fdel = childSnapshot.getValue(InterProcess.class);
                        detailsList.add(fdel);
                    }
                   CustomAdoptor customAdoptor= new CustomAdoptor();
                    club_list.setAdapter(customAdoptor);

                }else{

                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        return view;
    }
    class CustomAdoptor extends BaseAdapter {

        @Override
        public int getCount() {
            return detailsList.size();
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(final int i, View view, ViewGroup viewGroup) {
            view = getActivity().getLayoutInflater().inflate(R.layout.selected,null);
            TextView cnamee2=(TextView)view.findViewById(R.id.cnamee2);
            TextView stuusn=(TextView)view.findViewById(R.id.stuusn);
            TextView descr1=(TextView)view.findViewById(R.id.descr1);


            cnamee2.setText(detailsList.get(i).getCompany());
            stuusn.setText(detailsList.get(i).getUns());
            descr1.setText(detailsList.get(i).getDescrption());



            return view;
        }
    }
}
