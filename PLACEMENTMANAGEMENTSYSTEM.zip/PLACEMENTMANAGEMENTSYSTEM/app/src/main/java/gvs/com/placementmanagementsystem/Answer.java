package gvs.com.placementmanagementsystem;

import android.app.FragmentManager;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class Answer extends Fragment {
    String query,queryby;
    TextView textview_query;
    EditText answer;
    Button answer_button;
    DatabaseReference databaseReference;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_answer, container, false);
        databaseReference= FirebaseDatabase.getInstance().getReference("AnswerDetails");

        Bundle bundle=this.getArguments();
        query=bundle.getString("query");
        queryby=bundle.getString("qby");
        textview_query=(TextView)view.findViewById(R.id.questionn);
        textview_query.setText(query);
        answer=(EditText)view.findViewById(R.id.answerr);
        answer_button=(Button)view.findViewById(R.id.answer_button);
        answer_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String answer1=answer.getText().toString();
                if(answer1.length()>=4){
                final String id=databaseReference.push().getKey();
                AnswerModel achevementModel=new AnswerModel(id,query,answer1,queryby);
                databaseReference.child(id).setValue(achevementModel);
                Toast.makeText(getContext(),"Send Sucess",Toast.LENGTH_LONG).show();
                FragmentManager fm=getFragmentManager();

                fm.beginTransaction().replace(R.id.placement_fragment_container,new ViewQueryes()).commit();


            }else {
                    Toast.makeText(getContext(), "All Feilds Morethan 4 Characters", Toast.LENGTH_SHORT).show();

                }}
        });
        return view;
    }


}
