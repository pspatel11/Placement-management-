package gvs.com.placementmanagementsystem;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CalendarView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;


public class EligibleStudentsFragment extends Fragment {
    View view;
    ListView club_list;
    public static final String MyPREFERENCES = "MyPrefs";
    SharedPreferences sharedPreferences;
    DatabaseReference databaseReference,databaseReference2;
    List<StudentRegModel> detailsList;
    List<AcadamicModel> acadamicModelList;
    CalendarView calendarView;
    int cgpa,arrears,tength,twelth,sem;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_eligible_students, container, false);
        Bundle bundle=this.getArguments();
        cgpa=Integer.parseInt(bundle.getString("cgpa"));
        arrears=Integer.parseInt(bundle.getString("arrears"));
        tength=Integer.parseInt(bundle.getString("tength"));
        twelth=Integer.parseInt(bundle.getString("twelth"));
        sem=Integer.parseInt(bundle.getString("sem"));
        club_list=(ListView)view.findViewById(R.id.list_view);
        databaseReference= FirebaseDatabase.getInstance().getReference("StudentDetails");
        databaseReference2= FirebaseDatabase.getInstance().getReference("AcademicDetails");
        databaseReference2.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                acadamicModelList=new ArrayList<AcadamicModel>();
                for(DataSnapshot childSnapshot: dataSnapshot.getChildren()) {
                    AcadamicModel fdel = childSnapshot.getValue(AcadamicModel.class);
                    acadamicModelList.add(fdel);
                }
                if (dataSnapshot.exists()){
                    databaseReference.orderByChild("status").equalTo("Verified").addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            if(dataSnapshot.exists()){
                                detailsList=new ArrayList<StudentRegModel>();
                                for(DataSnapshot childSnapshot: dataSnapshot.getChildren()) {
                                    StudentRegModel studentRegModel = childSnapshot.getValue(StudentRegModel.class);
                                    Iterator<AcadamicModel> iterator = acadamicModelList.iterator();
                                    while (iterator.hasNext()){
                                        AcadamicModel acadamicModel2=iterator.next();
                                        if (acadamicModel2.getUsn().equalsIgnoreCase(studentRegModel.getSid())){
                                            if (Integer.parseInt(acadamicModel2.getTength())>=tength && Integer.parseInt(acadamicModel2.getTwelth())>=twelth && Integer.parseInt(acadamicModel2.getSem())>=sem && Integer.parseInt(acadamicModel2.getCgpa())>=cgpa && Integer.parseInt(acadamicModel2.getArrears())>=arrears){
                                                detailsList.add(studentRegModel);
                                            }
                                        }
                                    }
                                }
                                CustomAdoptor customAdoptor= new CustomAdoptor();
                                club_list.setAdapter(customAdoptor);
                            }
                        }
                        @Override
                        public void onCancelled(DatabaseError databaseError) {
                        }
                    });
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        return view;
    }

    class CustomAdoptor extends BaseAdapter {

        @Override
        public int getCount() {
            return detailsList.size();
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(final int i, View view, ViewGroup viewGroup) {
            view = getActivity().getLayoutInflater().inflate(R.layout.astu_list,null);
            TextView afid=(TextView)view.findViewById(R.id.asid1);
            TextView afname=(TextView)view.findViewById(R.id.asname1);
            TextView afstatus=(TextView)view.findViewById(R.id.astatus1);
            TextView asem=(TextView)view.findViewById(R.id.asem1);
            TextView abranch=(TextView)view.findViewById(R.id.abranch1);
            TextView phone=(TextView)view.findViewById(R.id.phone);

            afid.setText(detailsList.get(i).getSid());
            afname.setText(detailsList.get(i).getSname());
            afstatus.setText(detailsList.get(i).getStatus());
            final String id=detailsList.get(i).getId();
            abranch.setText(detailsList.get(i).getBranch());
            asem.setText(detailsList.get(i).getSem());
            phone.setText(detailsList.get(i).getSphone());
            return view;
        }
    }
}
