package gvs.com.placementmanagementsystem;

import android.app.FragmentManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


public class SendNotification extends Fragment {

    public static final String MyPREFERENCES = "MyPrefs";
    SharedPreferences sharedPreferences;

    Button add_btn;
    DatabaseReference databaseReference;
    DatabaseReference databaseReference2;
    EditText title,descc;
    Spinner cname;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final View view= inflater.inflate(R.layout.fragment_send_notification, container, false);
        databaseReference= FirebaseDatabase.getInstance().getReference("CompanyDetails");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                List<String> fdel=new ArrayList<>();
                for (DataSnapshot areaSnapshot: dataSnapshot.getChildren()) {


                    String areaName = areaSnapshot.child("companyName").getValue(String.class);
                    fdel.add(areaName);
                }
                Spinner areaSpinner = (Spinner)view.findViewById(R.id.companyspinner);
                final String[] areas = fdel.toArray(new String[fdel.size()]);
                ArrayAdapter<String> areasAdapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_item, areas);
                areasAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                areaSpinner.setAdapter(areasAdapter);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
       cname = (Spinner)view.findViewById(R.id.companyspinner);
       title=(EditText)view.findViewById(R.id.ntitle);
       descc=(EditText)view.findViewById(R.id.descc);
        Button button =(Button)view.findViewById(R.id.notifybutton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String cname1 = cname.getSelectedItem().toString();
                final String title1=title.getText().toString();
                final String descc1=descc.getText().toString();
                databaseReference2= FirebaseDatabase.getInstance().getReference("Notification_Details");

                databaseReference2.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                       String id=databaseReference2.push().getKey();
                       NotificationModel ndel=new NotificationModel();
                       ndel.setId(id);
                       ndel.setTitle(title1);
                       ndel.setDesscc(descc1);
                       ndel.setCompanyname(cname1);
                       databaseReference2.child(id).setValue(ndel);
                        Toast.makeText(getContext(), "Send Notification Sucess", Toast.LENGTH_SHORT).show();
                        FragmentManager fm=getFragmentManager();
                        fm.beginTransaction().replace(R.id.placement_fragment_container,new PHome()).commit();



                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });



            }
        });

        return view;
    }


}
