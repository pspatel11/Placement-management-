package gvs.com.placementmanagementsystem;

import android.app.FragmentManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Random;

public class AddCordinator extends Fragment {
    EditText name;
    EditText email;
    EditText password;
    EditText id;
    EditText phone;
    DatabaseReference databaseReference;
    Spinner branch;
    Button add_btn ;
    String cname,cemail,cphone,cbranch,cid;
    int otp;
Random random;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_add_cordinator, container, false);
        databaseReference= FirebaseDatabase.getInstance().getReference("CoordinatorDetails");

        ArrayList<String> type = new ArrayList<String>();
        type.add("CS");
        type.add("EEE");
        type.add("ECE");
        type.add("MECH");
        type.add("CIVIL");
        type.add("IT");

        final Spinner My_spinner1 = (Spinner)view.findViewById(R.id.fspiner);
        final ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(getContext(), android.R.layout.simple_list_item_1, type);
        My_spinner1.setAdapter(adapter1);
random=new Random();
        branch= (Spinner)view.findViewById(R.id.fspiner);

        name = ((EditText) view.findViewById(R.id.cname));
        email = ((EditText) view.findViewById(R.id.cemail));
        id = ((EditText) view.findViewById(R.id.cid));
        name = ((EditText) view.findViewById(R.id.cemail));
        phone = ((EditText) view.findViewById(R.id.cphone));
        add_btn=(Button) view.findViewById(R.id.freg_btn);
        add_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cname=name.getText().toString();
                cemail=email.getText().toString();
                cid=id.getText().toString();
                cphone=phone.getText().toString();
               cbranch = branch.getSelectedItem().toString();
               otp=random.nextInt(4561234);
                if(cname.length()>=4 && cid.length()>= 4 && cemail.length() >= 4 && cphone.length() ==10){
                    databaseReference.orderByChild("cid_phone_email").equalTo(cid+"_"+cphone+"_"+cemail).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            if(dataSnapshot.exists()){
                                Toast.makeText(getContext(), "Details already exists", Toast.LENGTH_SHORT).show();
                                FragmentManager fm=getFragmentManager();
                                fm.beginTransaction().replace(R.id.placement_fragment_container,new AddCordinator()).commit();

                            }else{
                                String key=databaseReference.push().getKey();
                                CoordinatorModel cdel=new CoordinatorModel();
                                cdel.setId(key);
                                cdel.setBranch(cbranch);
                                cdel.setCid(cid);
                                cdel.setEmail(cemail);
                                cdel.setName(cname);
                                cdel.setCid_password(cid+"_"+String.valueOf(otp));
                                cdel.setPassword(String.valueOf(otp));
                                cdel.setCid_phone_email(cid+"_"+cphone+"_"+cemail);
                                cdel.setPhone(cphone);
                                databaseReference.child(key).setValue(cdel);
                                new SimpleMail().sendEmail(cemail, "Login Credentials", "Use This credentials to login in your account"+"   Id:"+" "+cid+"   and Password: "+otp);

                                Toast.makeText(getContext(), "Details Added Sucess", Toast.LENGTH_SHORT).show();
                                FragmentManager fm=getFragmentManager();
                                fm.beginTransaction().replace(R.id.placement_fragment_container,new PHome()).commit();



                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }
                    });
                }else{
                    Toast.makeText(getContext(), "All Feilds Morethan 4 Characters", Toast.LENGTH_SHORT).show();

                }



            }
        });



        return view;
    }


}
