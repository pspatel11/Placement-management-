package gvs.com.placementmanagementsystem;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class PlacementCoordinator extends AppCompatActivity {
    SharedPreferences sharedPreferences;
    public static final String MyPREFERENCES = "MyPrefs" ;
     DatabaseReference databaseReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_placement_coordinator);
        databaseReference = FirebaseDatabase.getInstance().getReference().child("CoordinatorDetails");
        sharedPreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);

    }
    public void faculty(View view){
        final String email=((EditText)findViewById(R.id.flid)).getText().toString();
        final String password=((EditText)findViewById(R.id.flpassword)).getText().toString();
        if (email.length() <= 1 || password.length() <= 1 ) {
            Toast.makeText(getApplicationContext(), "All Fields Should be More then 3 Characters", Toast.LENGTH_SHORT).show();

        } else {

            databaseReference.orderByChild("cid_password").equalTo(email+"_"+password).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        for (DataSnapshot childSnapshot : dataSnapshot.getChildren()) {
                            String key = childSnapshot.getKey();
                            String branch = childSnapshot.child("branch").getValue().toString();
                            String email = childSnapshot.child("email").getValue().toString();
                            String cid = childSnapshot.child("cid").getValue().toString();
                            String name = childSnapshot.child("name").getValue().toString();
                            String phone = childSnapshot.child("phone").getValue().toString();

                            Log.d("name is", key);
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putString("name", name);
                            editor.putString("key", key);
                            editor.putString("email", email);
                            editor.putString("cid", cid);
                            editor.putString("branch", branch);
                            editor.putString("phone", phone);
                            editor.commit();
                            Log.d("keyis", key);
                            Intent intent = new Intent(getApplicationContext(), PlacementCoordinatorHome.class);
                            startActivity(intent);
                        }

                    } else {

                    }

                }


                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });


        }
}
}
