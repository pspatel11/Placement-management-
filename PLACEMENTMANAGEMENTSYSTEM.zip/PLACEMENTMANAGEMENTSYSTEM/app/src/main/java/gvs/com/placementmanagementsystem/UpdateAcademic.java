package gvs.com.placementmanagementsystem;

import android.app.FragmentManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class UpdateAcademic extends Fragment {

    EditText tenght;
    EditText tweth;
    EditText sem;
    EditText cgpa;
    EditText arrears;
    public static final String MyPREFERENCES = "MyPrefs";
    SharedPreferences sharedPreferences;
    DatabaseReference databaseReference;
    Button add_btn ;
    String ttwenth,twethh,semister,key,usn,tmarks,twmarks,semmarks,aid;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_update_academic, container, false);
        sharedPreferences = this.getActivity().getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);

        databaseReference= FirebaseDatabase.getInstance().getReference("AcademicDetails");
        key=sharedPreferences.getString("key","");
        usn=sharedPreferences.getString("sid","");
        tenght= (EditText) view.findViewById(R.id.tength1);
        tweth = ((EditText) view.findViewById(R.id.tweth1));
        sem = ((EditText) view.findViewById(R.id.sem1));
        add_btn=(Button)view.findViewById(R.id.aca_button1);
        cgpa = ((EditText) view.findViewById(R.id.cgpa));
        arrears = ((EditText) view.findViewById(R.id.arrears));
        Bundle bundle=this.getArguments();
        tmarks=bundle.getString("tength");
        twmarks=bundle.getString("twelth");
        semmarks=bundle.getString("sem");
        aid=bundle.getString("key");
        tenght.setText(tmarks);
        tweth.setText(twmarks);
        sem.setText(semmarks);
        cgpa.setText(bundle.getString("cgpa"));
        arrears.setText(bundle.getString("arrears"));
        add_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ttwenth=tenght.getText().toString();
                twethh=tweth.getText().toString();
                semister=sem.getText().toString();
                databaseReference.orderByChild("id").equalTo(aid).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if(dataSnapshot.exists()){
                            for(DataSnapshot childSnapshot: dataSnapshot.getChildren()) {
                            AcadamicModel acdel=childSnapshot.getValue(AcadamicModel.class);
                                acdel.setId(acdel.getId());
                                acdel.setSem(semister);
                                acdel.setStatus("NotVerified");
                                acdel.setTength(ttwenth);
                                acdel.setTwelth(twethh);
                                acdel.setUsn(usn);
                                acdel.setUsn_sem_tenght_twelth(usn+"_"+semister+"_"+ttwenth+"_"+twethh);
                                acdel.setUsn_status(usn+"_"+"NotVerified");
                                acdel.setCgpa(cgpa.getText().toString());
                                acdel.setArrears(arrears.getText().toString());
                                databaseReference.child(aid).setValue(acdel);
                                Toast.makeText(getContext(), "Updated Sucess", Toast.LENGTH_SHORT).show();
                                FragmentManager fm=getFragmentManager();
                                fm.beginTransaction().replace(R.id.student_fragment_container,new ViewAccadamics()).commit();



                            } }else{

                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
            }
        });
        return view;
    }

}
