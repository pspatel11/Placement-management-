package gvs.com.placementmanagementsystem;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class StudentRegister extends AppCompatActivity {
    EditText name;
    EditText email;
    EditText password;
    EditText fid;
    EditText fphone;
    EditText dob;
    EditText gender;
    Spinner branch,sem;
    Button add_btn ;
    DatabaseReference databaseReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_register);
        ArrayList<String> type = new ArrayList<String>();
        type.add("CS");
        type.add("EEE");
        type.add("ECE");
        type.add("MECH");
        type.add("CIVIL");
        type.add("IT");

        final Spinner My_spinner1 = (Spinner)findViewById(R.id.sspiner);
        final ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, type);
        My_spinner1.setAdapter(adapter1);

        ArrayList<String> sem = new ArrayList<String>();
        sem.add("1");
        sem.add("2");
        sem.add("3");
        sem.add("4");
        sem.add("5");
        sem.add("6");
        sem.add("7");
        sem.add("8");

        final Spinner My_spinner = (Spinner)findViewById(R.id.spinnersem);
        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, sem);
        My_spinner.setAdapter(adapter);
    }
    public void Studentreg(View view){
        final Spinner branch= (Spinner)findViewById(R.id.sspiner);
        final Spinner sem= (Spinner)findViewById(R.id.spinnersem);

        final String fname = ((EditText) findViewById(R.id.sname)).getText().toString();
        final String fid = ((EditText) findViewById(R.id.sid)).getText().toString();
        final String femail = ((EditText) findViewById(R.id.semail)).getText().toString();
        final String fphone = ((EditText) findViewById(R.id.sphone)).getText().toString();
        final String fdob = ((EditText) findViewById(R.id.sdob)).getText().toString();
        final String fpassword = ((EditText) findViewById(R.id.spass)).getText().toString();
        final String branch1 = branch.getSelectedItem().toString();
        final String sem1 = sem.getSelectedItem().toString();
        final String faddress = ((EditText) findViewById(R.id.saddress)).getText().toString();
        databaseReference= FirebaseDatabase.getInstance().getReference("StudentDetails");
        databaseReference.orderByChild("sid_email_phone").equalTo(fid+"_"+femail+"_"+fphone).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    Toast.makeText(StudentRegister.this, "Student already  Register ", Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(getApplicationContext(),StudentRegister.class);
                    startActivity(intent);
                }
                else{
                    String id = databaseReference.push().getKey();
                    StudentRegModel fdel=new StudentRegModel(fid,id,fname,femail,fphone,sem1,faddress,fdob,fpassword,"Not Verified",branch1,fid+"_"+femail+"_"+fphone,fid+"_"+fpassword+"_"+"NotVerified");
                    databaseReference.child(id).setValue(fdel);
                    Toast.makeText(StudentRegister.this, "Student   Register Sucess ", Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(getApplicationContext(),StudentLog.class);
                    startActivity(intent);


                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });



    }
}
