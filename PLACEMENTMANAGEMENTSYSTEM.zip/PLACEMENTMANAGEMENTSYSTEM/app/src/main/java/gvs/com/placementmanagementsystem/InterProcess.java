package gvs.com.placementmanagementsystem;

public class InterProcess {
    private String id;
    private String uns;
    private String company;
    private String descrption;

    public InterProcess() {
    }

    public InterProcess(String id, String uns, String company, String descrption) {
        this.id = id;
        this.uns = uns;
        this.company = company;
        this.descrption = descrption;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUns() {
        return uns;
    }

    public void setUns(String uns) {
        this.uns = uns;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getDescrption() {
        return descrption;
    }

    public void setDescrption(String descrption) {
        this.descrption = descrption;
    }
}
