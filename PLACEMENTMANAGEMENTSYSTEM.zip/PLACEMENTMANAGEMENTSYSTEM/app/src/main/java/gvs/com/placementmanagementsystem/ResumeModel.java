package gvs.com.placementmanagementsystem;

public class ResumeModel {
    private String id;
    private String resume;
    private String usn;
    private String usn_resume;

    public ResumeModel() {
    }

    public ResumeModel(String id, String resume, String usn, String usn_resume) {
        this.id = id;
        this.resume = resume;
        this.usn = usn;
        this.usn_resume = usn_resume;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getResume() {
        return resume;
    }

    public void setResume(String resume) {
        this.resume = resume;
    }

    public String getUsn() {
        return usn;
    }

    public void setUsn(String usn) {
        this.usn = usn;
    }

    public String getUsn_resume() {
        return usn_resume;
    }

    public void setUsn_resume(String usn_resume) {
        this.usn_resume = usn_resume;
    }
}
